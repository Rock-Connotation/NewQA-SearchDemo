//
//  AppDelegate.h
//  搜索demo
//
//  Created by 石子涵 on 2020/11/30.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

