//
//  SceneDelegate.h
//  搜索demo
//
//  Created by 石子涵 on 2020/11/30.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

