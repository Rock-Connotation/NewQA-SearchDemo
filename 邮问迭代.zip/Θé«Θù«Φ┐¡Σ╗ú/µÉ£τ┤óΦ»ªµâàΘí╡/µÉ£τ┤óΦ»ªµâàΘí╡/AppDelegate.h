//
//  AppDelegate.h
//  搜索详情页
//
//  Created by 石子涵 on 2020/11/29.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

