//
//  NOSearchResultsCV.h
//  搜索详情页
//
//  Created by 石子涵 on 2020/12/8.
//
/**搜索无结果页面*/

#import <UIKit/UIKit.h>

@class SearchEndCV;
NS_ASSUME_NONNULL_BEGIN

@interface NOSearchResultsCV : UIViewController

@end

NS_ASSUME_NONNULL_END
