//
//  ReleaseDynamicCV.h
//  搜索详情页
//
//  Created by 石子涵 on 2020/12/8.
//
/**发布动态页面*/
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ReleaseDynamicCV : UIViewController

@end

NS_ASSUME_NONNULL_END
