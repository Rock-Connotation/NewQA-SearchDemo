//
//  SearchBenginningCV.h
//  搜索详情页
//
//  Created by 石子涵 on 2020/11/29.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SearchBenginningCV : UIViewController

@end

NS_ASSUME_NONNULL_END
