//
//  SearchEndCV.m
//  搜索详情页
//
//  Created by 石子涵 on 2020/12/2.
//

#import "SearchEndCV.h"

@interface SearchEndCV ()

@end

@implementation SearchEndCV

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = NO;
    self.view.backgroundColor = [UIColor yellowColor];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
