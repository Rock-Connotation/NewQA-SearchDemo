//
//  HotSearchBtn.h
//  搜索详情页
//
//  Created by 石子涵 on 2020/12/1.
//
/**此button是热门搜索的btton，button会根据文字内容多少进行自适应宽度*/
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HotSearchBtn : UIButton
/// 文本内容
//@property (nonatomic, strong) UILabel *textLbl;
@end

NS_ASSUME_NONNULL_END
