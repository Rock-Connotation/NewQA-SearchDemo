//
//  SceneDelegate.h
//  QA_Search
//
//  Created by 石子涵 on 2020/11/19.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

