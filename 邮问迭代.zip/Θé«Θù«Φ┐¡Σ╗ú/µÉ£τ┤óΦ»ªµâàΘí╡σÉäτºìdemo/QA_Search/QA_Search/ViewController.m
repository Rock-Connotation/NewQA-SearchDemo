//
//  ViewController.m
//  QA_Search
//
//  Created by 石子涵 on 2020/11/19.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
