//
//  HotSearchViewModel.m
//  QA_Search
//
//  Created by 石子涵 on 2020/11/23.
//

#import "HotSearchViewModel.h"

@implementation HotSearchViewModel

@end
