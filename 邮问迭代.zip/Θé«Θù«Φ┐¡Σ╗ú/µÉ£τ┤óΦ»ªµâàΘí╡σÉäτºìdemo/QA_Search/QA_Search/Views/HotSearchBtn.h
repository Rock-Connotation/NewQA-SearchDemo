//
//  HotSearchBtn.h
//  QA_Search
//
//  Created by 石子涵 on 2020/11/19.
//
/**
 此button是热门搜索的btton，button会根据文字内容多少进行自适应宽度
 */
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HotSearchBtn : UIButton

@end

NS_ASSUME_NONNULL_END
