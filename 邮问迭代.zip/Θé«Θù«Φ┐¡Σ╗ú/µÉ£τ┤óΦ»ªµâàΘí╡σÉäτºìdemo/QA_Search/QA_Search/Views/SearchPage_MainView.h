//
//  SearchPage_MainView.h
//  QA_Search
//
//  Created by 石子涵 on 2020/11/19.
//

/**
 这个view是搜索页的主view
 */
#import <UIKit/UIKit.h>
#import <Masonry.h>             //用于约束
#import "SearchTopView.h"       //顶层的搜索view
NS_ASSUME_NONNULL_BEGIN

@interface SearchPage_MainView : UIView


@end

NS_ASSUME_NONNULL_END
