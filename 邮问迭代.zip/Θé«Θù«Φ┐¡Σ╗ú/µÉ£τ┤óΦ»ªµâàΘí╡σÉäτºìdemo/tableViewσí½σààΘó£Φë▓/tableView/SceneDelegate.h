//
//  SceneDelegate.h
//  tableView
//
//  Created by 石子涵 on 2020/11/26.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

