//
//  AppDelegate.h
//  点击删除该条cell的demo
//
//  Created by 石子涵 on 2020/11/25.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

